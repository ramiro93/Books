package com.projectbooks;

public class OnlineBookShop
{
  
  public static void main(String [] args) {
    //Scanner s = new
  
   
    
    BookStore books = new BookStore();
    
   books.loadData();
   books.displayByPrice(20, 25);
   books.displayByAuthor("Edgar Allen Poe");
  
  
   
      }

}
