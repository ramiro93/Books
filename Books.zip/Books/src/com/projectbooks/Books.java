package com.projectbooks;

public abstract class Books
{
String bookname;
String author;
int price;

abstract void display();
}
