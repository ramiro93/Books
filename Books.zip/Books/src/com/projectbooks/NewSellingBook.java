package com.projectbooks;

public class NewSellingBook extends Books

{
  String publisher;
  public NewSellingBook(String bookname, String author, int price, String publisher)
  {
    this.bookname = bookname;
    this.author = author;
    this.price = price;
    this.publisher = publisher;// TODO Auto-generated constructor stub
  }





 void display() {
   System.out.println("Name: " +this.bookname);
   System.out.println("Author: " +this.author);
   System.out.println("Price: " +this.price);
   System.out.println("Publisher: " + this.publisher);
 }

}
