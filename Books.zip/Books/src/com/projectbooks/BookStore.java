package com.projectbooks;

import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class BookStore 
{
  
  static ClassicBook fList[];
  static NewSellingBook sList[];
  
  
  void loadData() {
  fList = new ClassicBook[10];
  fList[0] = new ClassicBook("The Raven","Edgar Allen Poe", 23, 1985);
  fList[1] =  new ClassicBook("Cast of amantillado", "Edgar Allen Poe", 35, 1988);
  fList[2] = new ClassicBook("Mockingbird", "Ramiro Rojas", 22, 1870);
  fList[3] = new ClassicBook("My life", "Miriam Lopez", 35, 1800);
  fList[4] = new ClassicBook("Far away", "J.K Rawling", 45, 1789);
  fList[5] = new ClassicBook("Tell Tale Heart","Edgar Allen Poe", 23, 1985);
  fList[6] =  new ClassicBook("You,Me, and I", "Miriam Rojas", 35, 1988);
  fList[7] = new ClassicBook("Mockingbird Part 2", "Ramiro Rojas", 22, 1878);
  fList[8] = new ClassicBook("My life is Nothing but pain", "Miriam Lopez", 35, 1800);
  fList[9] = new ClassicBook("Far away from home and you", "J.K Rawling", 45, 1789);

  
  sList = new NewSellingBook[10];
  sList[0] = new NewSellingBook("Bye","Ramiro Rojas", 20, "Young Horse");
  sList[1] = new NewSellingBook("Your Love","Mia Johnson", 25, "Young Horse");
  sList[2] = new NewSellingBook("Hollow Heart","Tito Kubo", 20, "Viz Media");
  sList[3] = new NewSellingBook("Adios","Tito Kubo", 16, "Viz Media");
  sList[4] = new NewSellingBook("See You Soon","Stephen King", 20, "Young Horse");
  sList[5] = new NewSellingBook("Today is Life","Ramiro Rojas", 60, "Young Horse");
  sList[6] = new NewSellingBook("Your Love is mine","Mia Johnson", 25, "Young Horse");
  sList[7] = new NewSellingBook("Man Eater","Tito Kubo", 80, "Viz Media");
  sList[8] = new NewSellingBook("Chainsaw","Tito Kubo", 16, "Viz Media");
  sList[9] = new NewSellingBook("Farewell and GoodBye","Stephen King", 85, "Young Horse");


  

  
  }
  
  void displayByPrice(int startRange, int endRange) {
    System.out.println("1. Books in this price range are: ");
    try {
   for(int i = 0; i < fList.length; i++) {
     if(fList[i].price >= startRange && fList[i].price <= endRange) {
       System.out.println(fList[i].bookname);
     }
   }
   
   for(int i = 0; i < sList.length; i++) {
     if(fList[i].price >= startRange && sList[i].price <= endRange) {
       System.out.println(sList[i].bookname);
     }
   }
    }catch(Exception e) {
      System.out.println("No Book Found");
    }
 
  System.out.println("----------");
   
 }
    
    
  
  
  
  void displayByAuthor(String b) {
    System.out.println("2. Books with the same author are:");
    try {
  for(int i = 0; i <fList.length; i++) {
    if(fList[i].author.equals(b)) {
      System.out.println(fList[i].bookname);
    }
   
  }
  
  for(int i = 0; i <sList.length; i++) {
    if(sList[i].author.equals(b)) {
      System.out.println(sList[i].bookname);
    }
   
  }
    }catch(Exception e) {
      System.out.println("No books with same author");
    }
    
    System.out.println("----------");
     
   }
      
    }
    