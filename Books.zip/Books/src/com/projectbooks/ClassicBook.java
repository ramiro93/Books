package com.projectbooks;

public class ClassicBook extends Books
{
  
  int publishYear;
public ClassicBook(String bookname, String author, int price,int publishYear)
  {
    this.bookname = bookname;
    this.author = author;
    this.price = price;
    this.publishYear = publishYear;// TODO Auto-generated constructor stub
  }






@Override
void display() 
{
 System.out.println("Name: " +this.bookname);
 System.out.println("Author: " +this.author);
 System.out.println("Price: " +this.price);
 System.out.println("Publisher Year: " +this.publishYear);
  
}

}
